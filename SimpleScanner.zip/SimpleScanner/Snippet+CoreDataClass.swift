//
//  Snippet.swift
//  SimpleScanner
//
//  Created by Ronen Lahat on 6/10/2016.
//  Copyright © 2016 Ronen Lahat. All rights reserved.
//

import UIKit
import CoreData

//@objc(Snippet)
public class Snippet: NSManagedObject {

    
}
